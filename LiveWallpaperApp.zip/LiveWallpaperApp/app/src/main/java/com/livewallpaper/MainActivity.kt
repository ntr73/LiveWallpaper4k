package com.livewallpaper

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.livewallpaper.databinding.ActivityMainBinding

/**
 * Asosiy ekran:
 *  - Foydalanuvchi videolarni tanlaydi (SettingsActivity)
 *  - "Fon sifatida o'rnatish" tugmasini bosadi
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnOpenSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.btnSetWallpaper.setOnClickListener {
            setWallpaper()
        }
    }

    private fun setWallpaper() {
        // Android'ning standart Live Wallpaper o'rnatish oynasi
        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
            putExtra(
                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                ComponentName(this@MainActivity, VideoWallpaperService::class.java)
            )
        }
        startActivity(intent)
    }
}
