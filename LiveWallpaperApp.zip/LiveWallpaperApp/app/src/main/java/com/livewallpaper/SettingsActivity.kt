package com.livewallpaper

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.livewallpaper.databinding.ActivitySettingsBinding

/**
 * Foydalanuvchi Intro va Loop videolarini tanlaydi.
 * URI'lar SharedPreferences'ga saqlanadi.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    private val prefs by lazy {
        getSharedPreferences(VideoWallpaperService.PREFS_NAME, Context.MODE_PRIVATE)
    }

    /** Qaysi video tanlanayotganini kuzatamiz */
    private enum class PickTarget { INTRO, LOOP }
    private var currentPickTarget = PickTarget.INTRO

    // ── Permission launcher ───────────────────────────────────────────────────

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) openVideoPicker()
        else Toast.makeText(this, getString(R.string.permission_denied), Toast.LENGTH_SHORT).show()
    }

    // ── Video picker launcher ─────────────────────────────────────────────────

    private val videoPickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                // URI'ga doimiy ruxsat olamiz (ilova qayta ishlaganda ham ishlashi uchun)
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                saveUri(currentPickTarget, uri)
            }
        }
    }

    // ── onCreate ──────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadSavedUris()
        setupButtons()
    }

    // ── UI setup ──────────────────────────────────────────────────────────────

    private fun setupButtons() {
        binding.btnPickIntro.setOnClickListener {
            currentPickTarget = PickTarget.INTRO
            checkPermissionAndPick()
        }

        binding.btnPickLoop.setOnClickListener {
            currentPickTarget = PickTarget.LOOP
            checkPermissionAndPick()
        }

        binding.btnClearIntro.setOnClickListener {
            prefs.edit().remove(VideoWallpaperService.KEY_INTRO_URI).apply()
            updateIntroLabel(null)
            Toast.makeText(this, R.string.intro_cleared, Toast.LENGTH_SHORT).show()
        }

        binding.btnClearLoop.setOnClickListener {
            prefs.edit().remove(VideoWallpaperService.KEY_LOOP_URI).apply()
            updateLoopLabel(null)
            Toast.makeText(this, R.string.loop_cleared, Toast.LENGTH_SHORT).show()
        }
    }

    // ── URI management ────────────────────────────────────────────────────────

    private fun loadSavedUris() {
        val introUri = prefs.getString(VideoWallpaperService.KEY_INTRO_URI, null)
        val loopUri  = prefs.getString(VideoWallpaperService.KEY_LOOP_URI, null)
        updateIntroLabel(introUri?.let { Uri.parse(it) })
        updateLoopLabel(loopUri?.let { Uri.parse(it) })
    }

    private fun saveUri(target: PickTarget, uri: Uri) {
        val key = when (target) {
            PickTarget.INTRO -> VideoWallpaperService.KEY_INTRO_URI
            PickTarget.LOOP  -> VideoWallpaperService.KEY_LOOP_URI
        }
        prefs.edit().putString(key, uri.toString()).apply()

        when (target) {
            PickTarget.INTRO -> {
                updateIntroLabel(uri)
                Toast.makeText(this, R.string.intro_saved, Toast.LENGTH_SHORT).show()
            }
            PickTarget.LOOP  -> {
                updateLoopLabel(uri)
                Toast.makeText(this, R.string.loop_saved, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateIntroLabel(uri: Uri?) {
        binding.tvIntroStatus.text = if (uri != null) {
            getFileName(uri) ?: getString(R.string.video_selected)
        } else {
            getString(R.string.no_video_selected)
        }
    }

    private fun updateLoopLabel(uri: Uri?) {
        binding.tvLoopStatus.text = if (uri != null) {
            getFileName(uri) ?: getString(R.string.video_selected)
        } else {
            getString(R.string.no_video_selected)
        }
    }

    private fun getFileName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, arrayOf(MediaStore.Video.Media.DISPLAY_NAME),
                null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    // ── Permission & Picker ───────────────────────────────────────────────────

    private fun checkPermissionAndPick() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_VIDEO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

        when {
            ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED -> {
                openVideoPicker()
            }
            shouldShowRequestPermissionRationale(permission) -> {
                Toast.makeText(this, R.string.permission_rationale, Toast.LENGTH_LONG).show()
                permissionLauncher.launch(permission)
            }
            else -> {
                permissionLauncher.launch(permission)
            }
        }
    }

    private fun openVideoPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/mp4"
            // Doimiy ruxsat so'raymiz
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or
                     Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        videoPickerLauncher.launch(intent)
    }
}
