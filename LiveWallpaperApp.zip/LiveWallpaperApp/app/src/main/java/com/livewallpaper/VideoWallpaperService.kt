package com.livewallpaper

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.MediaPlayer
import android.net.Uri
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

/**
 * Video Live Wallpaper Service
 *
 * Ishlash tartibi:
 *  1. Ekran yonganida → INTRO video bir marta ijro etiladi
 *  2. Intro tugagach    → LOOP video cheksiz aylanadi
 *  3. Ekran o'chganda  → Barcha playerlar pauza qilinadi va xotira bo'shatiladi
 */
class VideoWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = VideoEngine()

    // -------------------------------------------------------------------------
    inner class VideoEngine : Engine() {

        private var introPlayer: MediaPlayer? = null
        private var loopPlayer: MediaPlayer? = null

        /** Hozir qaysi player aktiv ekranini kuzatamiz */
        private enum class State { IDLE, INTRO, LOOP, PAUSED }
        private var state = State.IDLE

        private val prefs by lazy {
            getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        }

        /** Ekran o'chish/yonish hodisalarini qabul qiluvchi */
        private val screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_SCREEN_OFF -> handleScreenOff()
                    Intent.ACTION_SCREEN_ON  -> handleScreenOn()
                }
            }
        }

        // ── Lifecycle ─────────────────────────────────────────────────────────

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)

            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
            }
            registerReceiver(screenReceiver, filter)
        }

        override fun onDestroy() {
            super.onDestroy()
            unregisterReceiver(screenReceiver)
            releaseAll()
        }

        // ── Surface ───────────────────────────────────────────────────────────

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            startIntro()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            super.onSurfaceDestroyed(holder)
            releaseAll()
        }

        // ── Visibility ────────────────────────────────────────────────────────

        override fun onVisibilityChanged(visible: Boolean) {
            if (visible) {
                handleScreenOn()
            } else {
                handleScreenOff()
            }
        }

        // ── Screen events ─────────────────────────────────────────────────────

        private fun handleScreenOn() {
            when (state) {
                State.IDLE, State.PAUSED -> startIntro()
                else -> { /* allaqachon ijro etilmoqda */ }
            }
        }

        private fun handleScreenOff() {
            pauseAll()
            state = State.PAUSED
        }

        // ── Playback ──────────────────────────────────────────────────────────

        /**
         * INTRO videosini ishga tushiradi.
         * Agar intro URI saqlanmagan bo'lsa, to'g'ridan-to'g'ri loopga o'tadi.
         */
        private fun startIntro() {
            val introUri = prefs.getString(KEY_INTRO_URI, null)

            if (introUri == null) {
                // Intro yo'q — bevosita loopga o'tamiz
                startLoop()
                return
            }

            releaseAll()
            state = State.INTRO

            try {
                introPlayer = MediaPlayer().apply {
                    setDataSource(applicationContext, Uri.parse(introUri))
                    setSurface(surfaceHolder.surface)
                    isLooping = false

                    // Intro tugagach loop boshlanadi
                    setOnCompletionListener { startLoop() }

                    setOnErrorListener { _, what, extra ->
                        android.util.Log.e(TAG, "Intro xatolik: what=$what extra=$extra")
                        startLoop()   // Xato bo'lsa ham loopga o'tamiz
                        true
                    }

                    prepare()
                    start()
                }
            } catch (e: Exception) {
                android.util.Log.e(TAG, "Intro ochib bo'lmadi: ${e.message}")
                startLoop()
            }
        }

        /**
         * LOOP videosini ishga tushiradi va cheksiz takrorlaydi.
         */
        private fun startLoop() {
            val loopUri = prefs.getString(KEY_LOOP_URI, null) ?: run {
                state = State.IDLE
                return
            }

            // Intro playerni tozalaymiz (loop davomida kerak emas)
            introPlayer?.release()
            introPlayer = null
            state = State.LOOP

            try {
                loopPlayer = MediaPlayer().apply {
                    setDataSource(applicationContext, Uri.parse(loopUri))
                    setSurface(surfaceHolder.surface)
                    isLooping = true   // ♾️ Cheksiz aylanish

                    setOnErrorListener { _, what, extra ->
                        android.util.Log.e(TAG, "Loop xatolik: what=$what extra=$extra")
                        state = State.IDLE
                        true
                    }

                    prepare()
                    start()
                }
            } catch (e: Exception) {
                android.util.Log.e(TAG, "Loop ochib bo'lmadi: ${e.message}")
                state = State.IDLE
            }
        }

        private fun pauseAll() {
            runCatching { introPlayer?.takeIf { it.isPlaying }?.pause() }
            runCatching { loopPlayer?.takeIf { it.isPlaying }?.pause() }
        }

        private fun releaseAll() {
            runCatching { introPlayer?.release() }
            runCatching { loopPlayer?.release() }
            introPlayer = null
            loopPlayer  = null
            state = State.IDLE
        }
    }

    companion object {
        const val TAG       = "VideoWallpaper"
        const val PREFS_NAME  = "wallpaper_prefs"
        const val KEY_INTRO_URI = "intro_uri"
        const val KEY_LOOP_URI  = "loop_uri"
    }
}
