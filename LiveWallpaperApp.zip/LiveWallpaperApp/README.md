# 🎬 Video Live Wallpaper — Android

MP4 videolardan **Intro + Loop** jonli fon yaratuvchi Android ilovasi.

## Qanday ishlaydi?

```
Ekran yonadi
    ↓
🎬 INTRO video (bir marta ijro etiladi)
    ↓
♾️  LOOP video (cheksiz aylanadi)
    ↓
Ekran o'chadi → pauza
```

---

## 📁 Loyiha strukturasi

```
app/src/main/
├── java/com/livewallpaper/
│   ├── VideoWallpaperService.kt   ← Asosiy servis (eng muhim!)
│   ├── MainActivity.kt            ← Bosh ekran
│   └── SettingsActivity.kt        ← Video tanlash ekrani
├── res/
│   ├── xml/wallpaper_info.xml     ← Live Wallpaper metadata
│   └── layout/ ...
└── AndroidManifest.xml
```

---

## 🚀 O'rnatish va build qilish

### Talablar
- Android Studio Hedgehog (2023.1.1) yoki yangroq
- JDK 17
- Android SDK 34

### Qadamlar

```bash
# 1. Loyihani oching
Android Studio → Open → LiveWallpaperApp/

# 2. Sync qiling
File → Sync Project with Gradle Files

# 3. Build → Generate Signed Bundle/APK
```

---

## 📱 Foydalanish

1. Ilovani oching
2. **"Videolarni tanlash"** tugmasini bosing
3. Intro videoni tanlang (ixtiyoriy)
4. Loop videoni tanlang (majburiy)
5. **"Fon sifatida o'rnatish"** tugmasini bosing
6. Tizim oynasida wallpaperni tasdiqlang

---

## ⚙️ Muhim texnik jihatlar

### Nima uchun `ACTION_OPEN_DOCUMENT`?
`ACTION_OPEN_DOCUMENT` + `takePersistableUriPermission()` kombinatsiyasi ilova qayta ishlaganda ham URI'ga kirishni ta'minlaydi. Oddiy `ACTION_GET_CONTENT` bilan URI eskirib qoladi.

### Screen on/off va Visibility
```kotlin
override fun onVisibilityChanged(visible: Boolean) {
    if (visible) playIntro() else pauseAll()
}
```
`onVisibilityChanged` Preview rejimida ham ishlaydi. Screen receiver esa real foydalanishda qo'shimcha ishonchlilik beradi.

### Intro → Loop o'tish
```kotlin
introPlayer?.setOnCompletionListener { startLoop() }
```
`isLooping = false` (default) bo'lgani uchun intro bir marta tugaydi, so'ng loop boshlanadi.

---

## 🔧 Play Store uchun

### app/build.gradle'da o'zgartiring:
```groovy
applicationId "com.sizningnomingiz.livewallpaper"  // o'zingiznikiga
versionCode 1
versionName "1.0.0"
```

### Ruxsatlar (allaqachon to'g'ri sozlangan):
- `READ_MEDIA_VIDEO` → Android 13+
- `READ_EXTERNAL_STORAGE` → Android 8-12

---

## 🐛 Muammolar va yechimlar

| Muammo | Yechim |
|--------|--------|
| Video ko'rinmaydi | URI to'g'ri saqlanganmi? Logcat'ni tekshiring |
| Ruxsat rad etildi | Settings → App → Permissions → Files |
| Loop o'ynamaydi | Loop URI saqlanganligini tekshiring |
| Ekran o'chganda freeze | `releaseAll()` to'g'ri chaqirilganini tekshiring |

---

## 📄 Litsenziya

MIT License — erkin foydalaning va tarqating.
