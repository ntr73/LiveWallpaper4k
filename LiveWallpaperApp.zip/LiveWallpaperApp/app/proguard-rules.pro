# LiveWallpaper ProGuard rules

# WallpaperService subclasslarni saqlash
-keep class com.livewallpaper.VideoWallpaperService { *; }
-keep class com.livewallpaper.VideoWallpaperService$VideoEngine { *; }

# Activity'larni saqlash
-keep class com.livewallpaper.MainActivity { *; }
-keep class com.livewallpaper.SettingsActivity { *; }

# MediaPlayer
-keep class android.media.MediaPlayer { *; }

# Kotlin coroutines
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
